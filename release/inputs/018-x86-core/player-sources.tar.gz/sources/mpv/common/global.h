#ifndef MPV_MPV_H
#define MPV_MPV_H
#include <stdatomic.h>

// This should be accessed by glue code only, never normal code.
// The only purpose of this is to make mpv library-safe.
// Think hard before adding new members.
struct mpv_global {
    unsigned long long host_generation;
    atomic_ullong host_session_id;
    atomic_ullong host_load_generation;
    struct mp_log *log;
    struct m_config_shadow *config;
    struct mp_client_api *client_api;
    char *configdir;
    struct stats_base *stats;
    struct demux_packet_pool *packet_pool;
};

#endif
